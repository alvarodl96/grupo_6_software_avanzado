# coding: utf-8

from __future__ import absolute_import
# import models into model package
from .asignatura import Asignatura
from .cambio import Cambio
from .cambio_departa import CambioDeparta
from .departamento import Departamento
from .profesor import Profesor
