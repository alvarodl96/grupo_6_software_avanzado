import connexion
from swagger_server.models.departamento import Departamento
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def delete_departamento(Num_Departamento):
    """
    Borra un departamento
    Borra un departamento del sistema
    :param Num_Departamento: Codigo del departamento a borrar
    :type Num_Departamento: int

    :rtype: None
    """
    return 'do some magic!'


def get_departamento(Codigo):
    """
    Obtiene un departamento
    Devuelve un departamento
    :param Codigo: Codigo del departamento
    :type Codigo: int

    :rtype: List[Departamento]
    """
    return 'do some magic!'


def post_departamento(departamento):
    """
    Crea departamento
    Añade un departamento al sistema
    :param departamento: El Departamento es creado
    :type departamento: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        departamento = Departamento.from_dict(connexion.request.get_json())
    return 'do some magic!'
