import connexion
from swagger_server.models.profesor import Profesor
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def delete_profesor(DNI_profesor):
    """
    Borra un profesor
    Borra un profesor del sistema
    :param DNI_profesor: DNI del profesor cuya matricula se quiera borrar
    :type DNI_profesor: int

    :rtype: None
    """
    return 'do some magic!'


def profesor_get(DNI_profesor):
    """
    Obtiene profesor
    Devuelve un profesor
    :param DNI_profesor: DNI del profesor
    :type DNI_profesor: int

    :rtype: List[Profesor]
    """
    return 'do some magic!'


def profesor_post(profesor):
    """
    Crea un profesor
    Añade una profesor al sistema
    :param profesor: El profesor que se crea
    :type profesor: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        profesor = Profesor.from_dict(connexion.request.get_json())
    return 'do some magic!'
