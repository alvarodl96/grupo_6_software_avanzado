import connexion
from swagger_server.models.asignatura import Asignatura
from swagger_server.models.cambio import Cambio
from swagger_server.models.cambio_departa import CambioDeparta
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def asigna_departamento(cambioDeparta):
    """
    Le pasa un departamento a la asignatura
    Actualiza un departamento a la asignatura
    :param cambioDeparta: Asignatura va a actualizarse
    :type cambioDeparta: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        cambioDeparta = CambioDeparta.from_dict(connexion.request.get_json())
    return 'do some magic!'


def asigna_profesor(cambio):
    """
    Le pasa un profesor a la asignatura
    Actualiza un profesor a la asignatura
    :param cambio: Asignatura va a actualizarse
    :type cambio: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        cambio = Cambio.from_dict(connexion.request.get_json())
    return 'do some magic!'


def delete_asignatura(Codigo):
    """
    Borra una asignatura
    Borra una asignatura de la base de datos
    :param Codigo: Codigo de la asignatura que se quiere borrar
    :type Codigo: int

    :rtype: None
    """
    return 'do some magic!'


def get_asignatura(Codigo):
    """
    Obtiene una asignatura
    Devuelve una asignatura
    :param Codigo: Codigo de la asignatura
    :type Codigo: int

    :rtype: List[Asignatura]
    """
    return 'do some magic!'


def post_asignatura(asignatura):
    """
    Crea una asignatura
    Añade una asignatura a la base de datos
    :param asignatura: La asignatura que se crea
    :type asignatura: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        asignatura = Asignatura.from_dict(connexion.request.get_json())
    return 'do some magic!'
